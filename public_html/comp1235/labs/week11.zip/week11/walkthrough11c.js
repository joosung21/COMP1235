let c = "GBC";
console.log("This is File C: ", c);
export { c }; // Exporting variable c
